package packteoria22;

public class Nagusia {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bidaia b1 = new Bidaia(10000,11000);
		Bidaia b2 = new Bidaia(20000,24500);
		Bidaia b3 = new Bidaia(4500,100000);
		
		ListaBidaiak lb1 = new ListaBidaiak();
		lb1.gehituBidaiBat(b1);
		lb1.gehituBidaiBat(b2);
		lb1.gehituBidaiBat(b3);
		System.out.println(lb1.bidaietanEgindakoKm());
		
		ListaBidaiak lb2 = new ListaBidaiak();
		lb2.gehituBidaiBat(b2);
		System.out.println(lb2.bidaietanEgindakoKm());
		
		ListaBidaiak lb3 = new ListaBidaiak();
		lb3.gehituBidaiBat(b1);
		lb3.gehituBidaiBat(b2);
		System.out.println(lb3.bidaietanEgindakoKm());
		
		Kotxea k1 = new Kotxea("1234HHH");
		k1.setEgindakoBidaiak(lb1);
		Kotxea k2 = new Kotxea("5678GGG");
		k2.setEgindakoBidaiak(lb2);
		Kotxea k3 = new Kotxea("9999BCD");
		k3.setEgindakoBidaiak(lb3);
		
		ListaKotxeak lk = new ListaKotxeak();
		lk.gehituKotxeBat(k1);
		lk.gehituKotxeBat(k2);
		lk.gehituKotxeBat(k3);
		
		System.out.println("1234HHH kotxearen kilometroak: "+lk.zenbatKmEginDitu("1234HHH"));
	}

}
