package partziala2016_1_Olatz;

import java.util.ArrayList;
import java.util.Iterator;

public class ListaSarreraIrteera {

	private ArrayList<SarreraIrteerak> listaSI;
	
	public ListaSarreraIrteera()
	{
		listaSI=new ArrayList<SarreraIrteerak>();
	}
	
	private Iterator<SarreraIrteerak> getIteradorea()
	{
		return this.listaSI.iterator();
	}

	public int egunBatekoMinutukoKop(int pUrtea, int pHilabetea, int pEguna) {
		Iterator<SarreraIrteerak> itr = getIteradorea();
		SarreraIrteerak si = null;		
		boolean pasaDa = false;
		int minutuak=0;
		while (itr.hasNext() && !pasaDa)
		{
			si = itr.next();
			if (si.egunaPasaDa(pUrtea, pHilabetea, pEguna)){
				pasaDa = true;
			}else if (si.egunaDa(pUrtea, pHilabetea, pEguna))
			{
				minutuak += si.minutuKop();
			}
		}
		return minutuak;
	}
	
	public void imprimatu() {
		Iterator<SarreraIrteerak> itr = this.getIteradorea();
		SarreraIrteerak SI = null;
		while (itr.hasNext())
		{
			SI = itr.next();
			SI.inprimatu();
		}
	}

	
}
