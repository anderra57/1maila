package partziala2016_1_Olatz;


public class Enpresa {

	private static Enpresa nireEnpresa = null;
	private ListaLangileak lista;
	
	private Enpresa() {
		lista = new ListaLangileak();
	}

	public static Enpresa getEnpresa()
	{
		if (nireEnpresa == null)
		{
			nireEnpresa = new Enpresa();
		}
		return nireEnpresa;
	}
	
	public void dataXOrduGehienSartuDuenLang(int pUrtea, int pHilabetea, int pEguna) {
		this.lista.dataXOrduGehienSartuDuenLang(pUrtea,pHilabetea,pEguna);
	}
}
