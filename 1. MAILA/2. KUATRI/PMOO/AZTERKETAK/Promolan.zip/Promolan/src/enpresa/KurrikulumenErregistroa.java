package enpresa;

public class KurrikulumenErregistroa {

	private static KurrikulumenErregistroa nireKurrikulumenErregistroa = null;
	private KurrikulumZerrenda kurrikulumenZerrenda;
			
	public KurrikulumenErregistroa(){
		kurrikulumenZerrenda = new KurrikulumZerrenda();
	}
	
	public static KurrikulumenErregistroa getKurrikulumenErregistroa(){
		if (nireKurrikulumenErregistroa==null){
			nireKurrikulumenErregistroa = new KurrikulumenErregistroa();
		}
		return nireKurrikulumenErregistroa;
	}
	
	public KurrikulumZerrenda getKurrikulumenZerrenda(){
		return this.kurrikulumenZerrenda;
	}
	
	public KurrikulumZerrenda hautatu(String pTitu, int pEspe){
		return KurrikulumenErregistroa.getKurrikulumenErregistroa().kurrikulumenZerrenda.hautatu(pTitu, pEspe);
	}
}
