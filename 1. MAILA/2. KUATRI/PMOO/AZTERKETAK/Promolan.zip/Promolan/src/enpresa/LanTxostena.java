package enpresa;

import java.util.ArrayList;
import java.util.Iterator;

public class LanTxostena {

	private ArrayList<Lana> lanpostuZerrenda;

	public LanTxostena() {
		this.lanpostuZerrenda = new ArrayList<Lana>();
	}

	private Iterator<Lana> getIteradorea() {
		return lanpostuZerrenda.iterator();
	}

	public void gehituLana(Lana pLan) {
		if (!badagoZerrendan(pLan)) {
			lanpostuZerrenda.add(pLan);
		} else {
			System.out.println("Iada existitzen da lan hori");
		}
	}

	public Boolean badagoZerrendan(Lana pLan) {
		Boolean badago = false;
		Iterator<Lana> it = getIteradorea();
		while (it.hasNext()) {
			Lana lan = it.next();
			if (lan.berdinakGara(pLan)) {
				badago = true;
			}
		}
		return badago;
	}

	public void hustuZerrenda() {
		this.lanpostuZerrenda.clear();
		this.lanpostuZerrenda = null;
	}

	public boolean onargarria(String pTitu, int pEspe) {
		Boolean emaitza = false;
		Iterator<Lana> it = this.getIteradorea();
		while (it.hasNext() && !emaitza) {
			Lana lan = it.next();
			if (lan.titulazioaDu(pTitu) && lan.lanEsperientziaBai(pEspe)) {
				emaitza = true;
			}
		}
		return emaitza;
	}
}
