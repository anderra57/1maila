package partziala2016_1_Olatz;

import java.util.ArrayList;
import java.util.Iterator;

public class ListaLangileak {

	private ArrayList<Langilea> langileZerrenda;
	
	public ListaLangileak()
	{
		langileZerrenda = new ArrayList<Langilea>();
	}
		
	private Iterator<Langilea> getIteradorea()
	{
		return this.langileZerrenda.iterator();
	}


	public void dataXOrduGehienSartuDuenLang(int pUrtea, int pHilabetea, int pEguna) {
		// TODO Auto-generated method stub
		Iterator<Langilea> itr = getIteradorea();
		Langilea lang = null;
		Langilea langMax = null;
		int iraupena = 0;
		int max = 0;
		while (itr.hasNext())
		{
			lang = itr.next();
			iraupena = lang.egunBatekoMinutukoKop(pUrtea, pHilabetea, pEguna);
			if (max < iraupena)
			{
				langMax=lang;
				max = iraupena;
			}
		}
		langMax.inprimatu();
	}
}
