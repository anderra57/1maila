#hasieraketak
num=int(input("Sartu zenbaki bat bitarrez eta 1ekin hasten dena"))
????

#sortu zenbakia hamartarrez
while(????):
    ????
 
    
print("Zenbakia hamartarrez honakoa da: ",  + ????)
