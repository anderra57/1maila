package packproiektua;

public class ListaGordelekuak {

	private ArrayList<Gordelekua> lista;
	
	public ListaGordelekuak(){
		this.lista = new ArrayList<Gordelekua>();
	}
}
