package packproiektua;

import java.util.ArrayList;
import java.util.Iterator;

public class ListaAkzioak {
	private ArrayList<Akzioa> lista;
	
	public ListaAkzioak(){
		this.lista = new ArrayList<Akzioa>();
	}
	public void printeatuAkzioa(){
		
	}
	public void akzioaAukeratu(){
		
	}
}
