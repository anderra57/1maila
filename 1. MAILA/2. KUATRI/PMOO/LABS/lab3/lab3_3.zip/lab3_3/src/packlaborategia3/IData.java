package packlaborategia3;

public interface IData
{
	public abstract void dataGehitu();
	public abstract void dataKendu();
 }
