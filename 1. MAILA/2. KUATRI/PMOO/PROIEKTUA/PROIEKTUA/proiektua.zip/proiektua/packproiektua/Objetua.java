package packproiektua;

public class Objetua {
	private String izena;
	
	public Objetua(String pIzena){
		this.izena=pIzena;
	}
	public String izenBerdina(String pObjIz){
		
	}
	public void objetuaErabili(int pObjIz){
		
	}
}
