package partziala2016_1_Olatz;

public class SarreraIrteerak {

	private int eguna;
	private int hilabetea;
	private int urtea;
	private int sOrdua;
	private int sMinutuak;
	private int iOrdua;
	private int iMinutuak;
	
	public SarreraIrteerak(int pEguna, int pHilabetea, int pUrtea, int pSordua, int pSminutuak)
	{
		this.eguna = pEguna;
		this.hilabetea = pHilabetea;
		this.urtea = pUrtea;
		this.sOrdua = pSordua;
		this.sMinutuak = pSminutuak;
		this.iOrdua = 0;
		this.iMinutuak = 0;
	}

	public boolean egunaDa(int pUrtea, int pHilabetea, int pEguna) {
		boolean da = false;
		da = (this.urtea == pUrtea && this.hilabetea == pHilabetea && this.eguna == pEguna); 
		return da;
	}
	public int minutuKop() {
		int sMin = this.sOrdua*60 + this.sMinutuak;
		int iMin = this.iOrdua*60 + this.iMinutuak;
		return (iMin - sMin);
	}
	
    public boolean egunaPasaDa(int pUrtea, int pHilabetea, int pEguna){
        boolean egunaPasaDa=false;
        if(this.urtea>pUrtea || this.hilabetea > pHilabetea || this.eguna>pEguna){
            egunaPasaDa=true;
        }
        return egunaPasaDa;
    }

    public void inprimatu() {
		System.out.println("Data: "+ this.urtea + "/" + this.hilabetea + "/" + this.eguna);
		System.out.println("Sarrera ordua: " + this.sOrdua + ":" + this.sMinutuak);
		System.out.println("Irteera ordua: " + this.iOrdua + ":" + this.iMinutuak + "\n");
	}
}
