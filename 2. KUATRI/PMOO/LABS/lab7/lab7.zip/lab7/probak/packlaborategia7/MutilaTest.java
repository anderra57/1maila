package packlaborategia7;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import packlaborategia7.ListaIkasleak;
import packlaborategia7.Mutila;
import packlaborategia7.Neska;

public class MutilaTest {
	Mutila mutila1,mutila2;
	Neska neska1,neska2;
	ListaIkasleak l1;

	@Before
	public void setUp() throws Exception {
		mutila1 = new Mutila("5356H","Adei","Arias",18);
		mutila2 = new Mutila("4752S","Ander","Prieto",18);
		neska1 = new Neska("7563L","Ane","Gomez",23);
		neska2 = new Neska("5311G","Maite","Larrimbe",18);
		l1 = new ListaIkasleak();
	}

	@After
	public void tearDown() throws Exception {
		mutila1 = null;
		mutila2 = null;
		neska1 = null;
		neska2 = null;
	}

	@Test
	public void testGehituPreferentzia() {
		mutila1.gehituPreferentzia(neska1);
		assertEquals(mutila1.getListaPreferentziak().badago(neska1), true);
		assertEquals(mutila1.getListaPreferentziak().badago(neska2), false);
	}

	@Test
	public void testMutila() {
		assertNotNull(mutila1);
		assertNotNull(mutila2);
		assertNotNull(neska1);
		assertNotNull(neska2);
	}

	@Test
	public void testOnartu() {
		mutila1.getListaPreferentziak().gehituIkaslea(neska1);
		assertTrue(mutila1.onartu(neska1));
		assertFalse(mutila1.onartu(neska2));
	}

}
