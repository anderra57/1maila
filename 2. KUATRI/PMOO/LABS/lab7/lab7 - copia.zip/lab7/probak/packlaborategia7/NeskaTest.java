package packlaborategia7;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import packlaborategia7.Mutila;
import packlaborategia7.Neska;

public class NeskaTest {
	Neska neska1,neska2;
	Mutila mutila1,mutila2;

	@Before
	public void setUp() throws Exception {
		neska1 = new Neska("2667L","Ane","Gomez",18);
		neska2 = new Neska("5743J","Maite","Larrimbe",18);
		mutila1 = new Mutila("5642H","Adei","Arias",18);
		mutila2 = new Mutila("7532W","Ander","Prieto",18);
	}

	@After
	public void tearDown() throws Exception {
		neska1 = null;
		neska2 = null;
		mutila1 = null;
		mutila2 = null;
	}

	@Test
	public void testGehituPreferentzia() {
		neska1.gehituPreferentzia(mutila1);
		assertEquals(neska1.getListaPreferentziak().badago(mutila1), true);
		assertEquals(neska1.getListaPreferentziak().badago(mutila2), false);
	}

	@Test
	public void testNeska() {
		assertNotNull(neska1);
		assertNotNull(neska2);
		assertNotNull(mutila1);
		assertNotNull(mutila2);
	}

	@Test
	public void testEnparejatu() {
		
	}

}
