package proiektua;

public class Laukia {
	//atributuak-atributos

	//eraikitzailea-constructora

	//gainontzeko metodoak-metodos adicionales
}
