package packproiektua;

public class Hilherria extends Egoera{
	
	public Hilherria(String pDeskribapena, ListaAkzioak pLista){
		super(pDeskribapena, pLista);
	}
	public void eszenatokiaInprimatu(){
		
	}
}
