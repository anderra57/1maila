def kaixo_mundua ():
    print("Kaixo mundua!!")
kaixo_mundua ()