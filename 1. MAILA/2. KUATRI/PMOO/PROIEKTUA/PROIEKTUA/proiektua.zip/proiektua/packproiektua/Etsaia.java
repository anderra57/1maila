package packproiektua;

public class Etsaia {
	
	private int bizitza;
	private int atq;
	
	public Etsaia(String pBizitza, int pAtq){
		this.atq = pAtq;
		this.bizitza = pBizitza;
	}
	
	public void eraso(int pAtq){
		
	}
}
