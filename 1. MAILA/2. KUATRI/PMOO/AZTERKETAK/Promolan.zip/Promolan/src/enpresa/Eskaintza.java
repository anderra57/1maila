package enpresa;

public class Eskaintza {

	private String enpresaIzena;
	private String NIF;
	private String titulazioa;
	private String hasieraData;
	private String amaieraData;
	private int soldata;
	private int lanegunKopurua;
	
	public Eskaintza(String pEnpresaIzena, String pNIF, String pTitulazioa,
			String pHasieraData, String pAmaieraData, int pSoldata, int pLanegunKopurua) {
		this.enpresaIzena = pEnpresaIzena;
		this.NIF = pNIF;
		this.titulazioa = pTitulazioa;
		this.hasieraData = pHasieraData;
		this.amaieraData = pAmaieraData;
		this.soldata = pSoldata;
		this.lanegunKopurua = pLanegunKopurua;
	}
	
	public boolean berdinakGara(Eskaintza pEsk) {
		Boolean berdinak = false;
		if (this.enpresaIzena.equals(pEsk.enpresaIzena) &&
				this.NIF.equals(pEsk.NIF) &&
				this.titulazioa.equals(pEsk.titulazioa) &&
				this.hasieraData.equals(pEsk.hasieraData) &&
				this.amaieraData.equals(pEsk.amaieraData) &&
				this.soldata==pEsk.soldata &&
				this.lanegunKopurua==pEsk.lanegunKopurua){
			berdinak = true;
		}
		return berdinak;
	}

	public String getTitulazioa(){
		return this.titulazioa;
	}
	
	public KurrikulumZerrenda eskaintzaKudeatu() {
		KurrikulumZerrenda zerrenda = KurrikulumenErregistroa.getKurrikulumenErregistroa().hautatu(this.titulazioa,this.lanegunKopurua);
		return zerrenda;
	}
	
	
	
}
