package enpresa;

import java.util.Calendar;

public class ProgramaNagusia {

	public static void main(String[] args) {
		
		Eskaintza es1 = new Eskaintza("Burton", "1111A", "ingenieria", "01/01/2015", "01/01/2016", 3000, 1000);
		Eskaintza es2 = new Eskaintza("Hero", "2222B", "kamareroa", "01/01/2015", "01/06/2016", 1500, 300);
		Eskaintza es3 = new Eskaintza("Oakley", "3333D", "administratzailea", "01/01/2015", "01/09/2017", 2000, 500);
		
		EskaintzenZerrenda zerrendaEskaintzak = EskaintzenZerrenda.getEskaintzenZerrenda();
		zerrendaEskaintzak.gehituEskaintza(es1);
		zerrendaEskaintzak.gehituEskaintza(es2);
		zerrendaEskaintzak.gehituEskaintza(es3);
				
		Kurrikuluma kur1 = new Kurrikuluma("Xabi", "1212A", "Donostia", "xabi@gmail.com", 25, "arkitektoa", 9);
		Kurrikuluma kur2 = new Kurrikuluma("Raul", "3434B", "Bilbo", "raul@gmail.com", 24, "arkitektoa", 8); 
		Kurrikuluma kur3 = new Kurrikuluma("Amaia", "5656D", "Gasteiz", "amaia@gmail.com", 23, "ingenieria", 9);
		Kurrikuluma kur4 = new Kurrikuluma("Naiara", "7878E", "Iruña", "naiara@gmail.com", 26, "ingenieria", 5); 
		Kurrikuluma kur5 = new Kurrikuluma("Jon", "9090F", "Baiona", "jon@gmail.com", 26, "ingenieria", 8); 
		
		Calendar data1 = Calendar.getInstance();
		data1.set(2010, 10, 25);
		Calendar data2 = Calendar.getInstance();
		data2.set(2010, 10, 28);	
		Lana lan1 = new Lana("kamareroa", data1, data2);
		
		data1 = Calendar.getInstance();
		data2 = Calendar.getInstance();
		data1.set(2010, 10, 25);
		data2.set(2011, 10, 28);	
		Lana lan2 = new Lana("kamareroa", data1, data2);
		
		data1 = Calendar.getInstance();
		data2 = Calendar.getInstance();
		data1.set(2010, 10, 25);
		data2.set(2011, 10, 28);	
		Lana lan3 = new Lana("kamareroa", data1, data2);
		
		data1 = Calendar.getInstance();
		data2 = Calendar.getInstance();
		data1.set(2010, 10, 25);
		data2.set(2012, 10, 28);	
		Lana lan4 = new Lana("kamareroa", data1, data2);
		
		data1 = Calendar.getInstance();
		data2 = Calendar.getInstance();
		data1.set(2010, 10, 25);
		data2.set(2013, 10, 28);	
		Lana lan5 = new Lana("kamareroa", data1, data2);
		
		
		kur1.gehituLana(lan1);
		kur2.gehituLana(lan2);
		kur3.gehituLana(lan3);
		kur4.gehituLana(lan4);
		kur5.gehituLana(lan5);
		
		KurrikulumenErregistroa kurrikulumErreg = KurrikulumenErregistroa.getKurrikulumenErregistroa();
		kurrikulumErreg.getKurrikulumenZerrenda().gehituKurrikulum(kur1);
		kurrikulumErreg.getKurrikulumenZerrenda().gehituKurrikulum(kur2);
		kurrikulumErreg.getKurrikulumenZerrenda().gehituKurrikulum(kur3);
		kurrikulumErreg.getKurrikulumenZerrenda().gehituKurrikulum(kur4);
		kurrikulumErreg.getKurrikulumenZerrenda().gehituKurrikulum(kur5);
		
		zerrendaEskaintzak.eskaintzakKudeatu();
	
	}

}