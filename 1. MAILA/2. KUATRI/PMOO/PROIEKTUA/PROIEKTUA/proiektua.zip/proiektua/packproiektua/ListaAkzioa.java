package packproiektua;

public class ListaAkzioa {

	private ArrayList<Kazioa> lista;
	private Ona ona1;
	
	
	public ListaAkzioak(){
		this.lista = new ArrayList<Akzioa>();
	}
	public Akzioa printeatuAkzioa(){
		
	}
	public Akzioa akzioaAukeratu(){
		
	}
	
}
