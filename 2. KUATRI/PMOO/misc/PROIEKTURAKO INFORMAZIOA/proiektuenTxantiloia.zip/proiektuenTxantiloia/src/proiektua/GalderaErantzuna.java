package proiektua;

public class GalderaErantzuna {
	//atributuak-atributos

	//eraikitzailea-constructora

	//gainontzeko metodoak-metodos adicionales
}
