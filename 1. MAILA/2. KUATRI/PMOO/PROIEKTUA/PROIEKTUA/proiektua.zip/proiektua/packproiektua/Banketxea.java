package packproiektua;

public class Banketxea extends Egoera{
	
	public Banketxea(String pDeskribapena, ListaAkzioak pLista){
		super(pDeskribapena, pLista);
	}
	public void eszenatokiaInprimatu(){
		
	}
}
