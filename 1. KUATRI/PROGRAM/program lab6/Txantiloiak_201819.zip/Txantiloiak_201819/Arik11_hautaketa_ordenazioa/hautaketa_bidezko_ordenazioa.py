def bektorea_idatzi(bek):
	?????

def trukatu(bek,posA,posB):
	??????????
	
	return(bek)

def bilatu_minimoaren_posizioa(bek,hasieraPos):
#Aurre:	  0 <= hasieraPos < len(bek)
#Post:    minPos-en balio minimoa duen elementuaren posizioa jasotzen du, 
#         hasieraPos eta len(bek) artekoak
        ?????

	return(???)

def hautaketa_bidezko_ordenazioa(bek):
    ????
    
    return(bek)

def nagusia():
     #1. kasua
     bektorea1 = [9, 5, 3, 4, 10, 8, 13, 24, 15, 11]
     
     print("Hasierako bektorea: (9,5,3,4,10,8,13,24,15,11):")
     bektorea_idatzi(bektorea1)

     bektorea1=hautaketa_bidezko_ordenazioa(bektorea1)
     print("Bukaerako bektorea honakoa beharko luke (3,4,5,8,9,10,11,13,15,24) eta emaitza:")
     bektorea_idatzi(bektorea1)

     # Proba kasuak falta dira
        
nagusia()
