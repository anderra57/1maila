package enpresa;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

public class KurrikulumZerrenda {

	private ArrayList<Kurrikuluma> kurrikulumZerrenda;
	
	public KurrikulumZerrenda(){
		kurrikulumZerrenda = new ArrayList<Kurrikuluma>();
	}
	
	public ArrayList<Kurrikuluma> getKurrikulumenZerrenda (){
		return this.kurrikulumZerrenda;
	}
	
	private Iterator<Kurrikuluma> getIteradorea(){
		return kurrikulumZerrenda.iterator();
	}
	
	public void gehituKurrikulum(Kurrikuluma pkur){
		if (!badagoZerrendan(pkur)){
			kurrikulumZerrenda.add(pkur);
		}
		else {
			System.out.println("Iada existitzen da kurrikumlum hori");;
		}
	}
	
	public Boolean badagoZerrendan(Kurrikuluma pkur){
		Boolean badago = false;
		Iterator<Kurrikuluma> it = getIteradorea();
		while(it.hasNext()){
			Kurrikuluma kur = it.next();
			if (kur.berdinakGara(pkur)){
				badago = true;
			}
		}
		return badago;
	}
	
	public KurrikulumZerrenda hautatu(String pTitu, int pEspe){
		Collections.sort(kurrikulumZerrenda, new Comparator<Kurrikuluma>() {
			@Override
			public int compare(Kurrikuluma k1, Kurrikuluma k2) {
				return new Integer(k2.getKalifikazioa()).compareTo(new Integer(k1.getKalifikazioa()));
			}
		});
	    KurrikulumZerrenda zerrendaBerria = new KurrikulumZerrenda();
		Iterator<Kurrikuluma> it = this.getIteradorea();
		while(it.hasNext()){
			Kurrikuluma ku = it.next();
			if (ku.baldintzaBetetzenDu(pTitu,pEspe)){
				zerrendaBerria.gehituKurrikulum(ku);
			}
		}
		
		return zerrendaBerria;
	}
	
	public void imprimatu(){
		Iterator<Kurrikuluma> it = this.getIteradorea();
		Boolean hutsa = false;
		int kont = 1;
		while(it.hasNext() && kont<4){
			hutsa = true;
			kont++;
			Kurrikuluma ku = it.next();
			ku.imprimatu();
		}
		if (!hutsa){
			System.out.println("Ez dago hautagairik eskaintza honetarako");
		}
	}
	
	public void hustuZerrenda(){
		this.kurrikulumZerrenda.clear();
		this.kurrikulumZerrenda = null;
	}
}
