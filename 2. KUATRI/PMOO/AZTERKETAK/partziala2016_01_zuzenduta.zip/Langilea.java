package partziala2016_1_Olatz;

public class Langilea {

	private int nan;
	private ListaSarreraIrteera lista;
	
	
	public Langilea(int pNan)
	{
		this.nan=pNan;
		this.lista = new ListaSarreraIrteera();
	}

	public int egunBatekoMinutukoKop(int pUrtea, int pHilabetea, int pEguna) {
		return this.lista.egunBatekoMinutukoKop(pUrtea, pHilabetea, pEguna);
	}

	public void inprimatu() {
		System.out.println("Nan: " + this.nan);
		this.lista.imprimatu();
	}
}
