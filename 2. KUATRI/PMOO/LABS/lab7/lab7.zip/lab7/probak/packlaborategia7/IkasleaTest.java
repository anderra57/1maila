package packlaborategia7;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import packlaborategia7.Ikaslea;
import packlaborategia7.ListaIkasleak;
import packlaborategia7.Mutila;
import packlaborategia7.Neska;

public class IkasleaTest {
	Ikaslea mutila1, mutila2, neska1, neska2;
	ListaIkasleak l1;
	@Before
	public void setUp() throws Exception {
		mutila1 = new Mutila("5642H","Adei","Arias",18);
		mutila2 = new Mutila("7532W","Ander","Prieto",18);
		neska1 = new Neska("7563L","Ane","Gomez",23);
		neska2 = new Neska("5311G","Maite","Larrimbe",18);
		l1 = new ListaIkasleak();
	}

	@After
	public void tearDown() throws Exception {
		mutila1 = null;
		mutila2 = null;
		neska1 = null;
		neska2 = null;
	}

	@Test
	public void testIkaslea() {
		assertNotNull(mutila1);
		assertNotNull(mutila2);
		assertNotNull(neska1);
		assertNotNull(neska2);
	}

	@Test
	public void testGetListaPreferentziak() {
		assertEquals(mutila1.getListaPreferentziak(), this.l1);
	}

	@Test
	public void testGetIzena() {
		assertEquals(mutila1.getIzena(), "Adei");
	}

	@Test
	public void testGetAbizena() {
		assertEquals(mutila1.getAbizena(), "Arias");
	}

	@Test
	public void testGetAdina() {
		assertEquals(mutila1.getAdina(), 18);
	}

	@Test
	public void testGetNAN() {
		assertEquals(mutila1.getNAN(), "5642H");
	}

	@Test
	public void testGehituPreferentzia() {
		mutila1.getListaPreferentziak().gehituIkaslea(neska1);
		mutila1.getListaPreferentziak().gehituIkaslea(neska2);
		assertEquals(mutila1.getListaPreferentziak().getTamaina(), 2);
	}

}
