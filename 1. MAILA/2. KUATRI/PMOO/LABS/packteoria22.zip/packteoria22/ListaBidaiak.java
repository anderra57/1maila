package packteoria22;

import java.util.ArrayList;
import java.util.Iterator;

public class ListaBidaiak {
	private ArrayList<Bidaia> lista;
	
	public ListaBidaiak(){
		// Konturatu ez dugula ArrayLista parametro gisa jasotzen, berria sortzen dugu!!!!
		lista = new ArrayList<Bidaia>();
	}
	
	public boolean gehituBidaiBat(Bidaia pBidaia){
		return lista.add(pBidaia);
	}
	
	private Iterator<Bidaia> getIteradorea(){
		return this.lista.iterator();
	}

	public int bidaietanEgindakoKm(){
		Iterator<Bidaia> itr = this.getIteradorea();
		int kmTot = 0;
		while (itr.hasNext()){
			Bidaia b1 = itr.next();
			kmTot += b1.bidaiarenKm();
		}
		return kmTot;
	}

}
