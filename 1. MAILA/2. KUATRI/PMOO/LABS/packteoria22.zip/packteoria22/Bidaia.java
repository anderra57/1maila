package packteoria22;

public class Bidaia {
	private int hasierakoKm;
	private int bukaerakoKm;
	
	public Bidaia(int pHasiera, int pBukaera){
		this.hasierakoKm = pHasiera;
		this.bukaerakoKm = pBukaera;
	}

	public int getHasierakoKm() {
		return hasierakoKm;
	}

	public void setHasierakoKm(int hasierakoKm) {
		this.hasierakoKm = hasierakoKm;
	}

	public int getBukaerakoKm() {
		return bukaerakoKm;
	}

	public void setBukaerakoKm(int bukaerakoKm) {
		this.bukaerakoKm = bukaerakoKm;
	}
	
	
	public int bidaiarenKm(){
		return this.getBukaerakoKm()-this.getHasierakoKm();
	}

}
