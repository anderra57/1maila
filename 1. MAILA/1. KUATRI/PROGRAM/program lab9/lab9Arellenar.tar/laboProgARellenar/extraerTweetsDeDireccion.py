import ListaTweetsPruebaAlumnos


miListaTweets = ListaTweetsPruebaAlumnos.ListaTweets()
miListaTweets.__init_LT__

miListaTweets.extraerTweetsDireccion()


