package packproiektua;

import java.util.ArrayList;
import java.util.Iterator;

public class Inbentarioa {
	private ArrayList<Objetua>lista;
	
	public Inbentarioa(){
		this.lista = ArrayList<Objetua>();
	}
	public Objetua objetuaBilatu(Objetua pObjetua){
		
	}
	public void objetuaErabili(){
		
	}
	public void objetuaErabili(int pObjIz){
		
	}
}
