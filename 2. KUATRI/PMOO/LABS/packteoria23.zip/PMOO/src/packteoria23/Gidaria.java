package packteoria23;

public class Gidaria {
	private String izena;
	private String nazionalitatea;
	private boolean lizentzia;
	
	public Gidaria(String pIzena, String pNazionalitatea, boolean pLizentzia){
		this.izena = pIzena;
		this.nazionalitatea = pNazionalitatea;
		this.lizentzia = pLizentzia;
	}
	
	public boolean lizentziaIndarrean(){
		return this.lizentzia;
	}
	
	public void gidariaInprimatu(){
		System.out.println("Gidariaren izena: "+this.izena+", "+this.nazionalitatea);
	}

}
