package proiektua;

public class Jokalaria {
	//atributuak-atributos

	//eraikitzailea-constructora

	//gainontzeko metodoak-metodos adicionales
}
