package enpresa;

import java.util.Calendar; 

public class Lana {

	private String titulazioa;
	private Calendar hasieraData;
	private Calendar amaieraData;

	public Lana(String pTitulazioa, Calendar pHasieraData, Calendar pAmaieraData) {
		this.titulazioa = pTitulazioa;
		this.hasieraData = pHasieraData;
		this.amaieraData = pAmaieraData;
	}

	public boolean berdinakGara(Lana pLan) {
		Boolean emaitza = false;
		if (this.titulazioa.equals(pLan.titulazioa)
				&& this.hasieraData.equals(pLan.hasieraData)
				&& this.amaieraData.equals(pLan.amaieraData)) {
			emaitza = true;
		}
		return emaitza;
	}

	public boolean titulazioaDu(String pTitu) {
		Boolean emaitza = false;
		if (this.titulazioa.equals(pTitu)) {
			emaitza = true;
		}
		return emaitza;
	}

	public boolean lanEsperientziaBai(int pEspe) {
		Boolean emaitza = false;
		if (pEspe<=this.zenbatLanEgun()) {
			emaitza = true;
		}
		return emaitza;
	}

	private long zenbatLanEgun() {
				
		// balioa milisegunduetara pasatzen da
		long milis1 = hasieraData.getTimeInMillis();
		long milis2 = amaieraData.getTimeInMillis();

		// bi daten arteko diferentzia kalkulatzen da
		long diff = milis2 - milis1;

//		// Diferentzia segunduetan kalkulatzeko
//		long diffSeconds = Math.abs(diff / 1000);
//
//		// Diferentzia minutuetan kalkulatzeko
//		long diffMinutes = Math.abs(diff / (60 * 1000));
//
//		// Diferentzia orduetan kalkulatzeko
//		long diffHours = Math.abs(diff / (60 * 60 * 1000));

		// Diferentzia egunetan kalkulatzeko
		long diffDays = Math.abs(diff / (24 * 60 * 60 * 1000));

		
		return diffDays;
	}

}
