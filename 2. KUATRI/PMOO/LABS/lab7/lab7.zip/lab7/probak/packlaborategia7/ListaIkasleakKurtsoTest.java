package packlaborategia7;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import packlaborategia7.Ikaslea;
import packlaborategia7.ListaIkasleakKurtso;
import packlaborategia7.Mutila;
import packlaborategia7.Neska;

public class ListaIkasleakKurtsoTest {
	Ikaslea mutila1,mutila2,neska1,neska2;
	ListaIkasleakKurtso l1 = ListaIkasleakKurtso.getListaIkasleakKurtso();

	@Before
	public void setUp() throws Exception {
		mutila1 = new Mutila("5642H","Adei","Arias",18);
		mutila2 = new Mutila("7532W","Ander","Prieto",18);
		neska1 = new Neska("7563L","Ane","Gomez",23);
		neska2 = new Neska("5311G","Maite","Larrimbe",18);
	}

	@After
	public void tearDown() throws Exception {
		mutila1 = null;
		mutila2 = null;
		neska1 = null;
		neska2 = null;
		l1 = null;		
	}

	@Test
	public void testGetListaIkasleakKurtso(){
		assertNotNull(ListaIkasleakKurtso.getListaIkasleakKurtso());
	}

	@Test
	public void testGehituIkasleaKurtsoan() {
		l1.erreseteatu();
		l1.getListaIkasleakKurtso().gehituIkasleaKurtsoan(mutila1);
		l1.getListaIkasleakKurtso().gehituIkasleaKurtsoan(neska1);
	}

	@Test
	public void testErreseteatu() {
		l1.getListaIkasleakKurtso().erreseteatu();
	}

	@Test
	public void testBilatuIkasleaNANez() {
		l1.getListaIkasleakKurtso().erreseteatu();
		assertEquals(l1.getListaIkasleakKurtso().bilatuIkasleaNANez("7563L"), null);
		l1.getListaIkasleakKurtso().gehituIkasleaKurtsoan(mutila2);
		l1.getListaIkasleakKurtso().gehituIkasleaKurtsoan(neska1);
		assertEquals(l1.getListaIkasleakKurtso().bilatuIkasleaNANez("7532W").getNAN(), "7532W");
		assertEquals(l1.getListaIkasleakKurtso().bilatuIkasleaNANez("7563L").getNAN(), "7563L");
	}

	@Test
	public void testBadagoIkaslerikBikoterikGabe() {
		assertFalse(l1.getListaIkasleakKurtso().badagoIkaslerikBikoterikGabe());
		
	}

}
