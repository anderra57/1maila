#hasieraketak
zenb=int(input("Sartu osoko zenbaki bat: "))
????

#lortu digituak eta zenbatu digitua bakoitia bada
while(????):
    zenb = zenb --- 10
    ????
    
print("Zuk sartutako zenbakiak " + ???? + "digitu bakoiti ditu.")
