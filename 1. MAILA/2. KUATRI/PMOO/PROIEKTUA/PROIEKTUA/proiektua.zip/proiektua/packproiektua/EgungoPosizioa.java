package packproiektua;

public class EgungoPosizioa {
	
	private int x;
	private int y;
	
	public EgungoPosizioa(int pX, int pY){
		this.x = pX;
		this.y = pY;
	}
	public int posizioazAldatu(int pX,int pY){
		
	}
}
