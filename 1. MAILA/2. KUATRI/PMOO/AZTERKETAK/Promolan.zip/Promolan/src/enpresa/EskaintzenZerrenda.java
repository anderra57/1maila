package enpresa;

import java.util.ArrayList;
import java.util.Iterator;

public class EskaintzenZerrenda {

	private ArrayList<Eskaintza> zerrendaEskaintza;
	private static EskaintzenZerrenda nireEskaintzenZerrenda = null;

	public EskaintzenZerrenda(){
		zerrendaEskaintza = new ArrayList<Eskaintza>();
	}
	
	public static EskaintzenZerrenda getEskaintzenZerrenda(){
		if (nireEskaintzenZerrenda==null){
			nireEskaintzenZerrenda = new EskaintzenZerrenda();
		}
		return nireEskaintzenZerrenda;
	}

	private Iterator<Eskaintza> getIteradorea(){
		return zerrendaEskaintza.iterator();
	}
	
	public void gehituEskaintza(Eskaintza pEsk){
		if (!badagoZerrendan(pEsk)){
			zerrendaEskaintza.add(pEsk);
		}
		else {
			System.out.println("Iada existitzen da lan eskaintza hori");;
		}
	}
	
	public Boolean badagoZerrendan(Eskaintza pEsk){
		Boolean badago = false;
		Iterator<Eskaintza> it = getIteradorea();
		while(it.hasNext()){
			Eskaintza es = it.next();
			if (es.berdinakGara(pEsk)){
				badago = true;
			}
		}
		return badago;
	}
	
	public void hustuZerrenda(){
		this.zerrendaEskaintza.clear();
		this.zerrendaEskaintza = null;
	}
	
		
	public void eskaintzakKudeatu(){
		KurrikulumZerrenda emaitzaZerrenda;
		Iterator<Eskaintza> it = getIteradorea();
		while(it.hasNext()){
			Eskaintza eska = it.next();
			emaitzaZerrenda = eska.eskaintzaKudeatu();
			System.out.println(eska.getTitulazioa()+": ");			
			emaitzaZerrenda.imprimatu();
			System.out.println("");
		}	
	}
}
