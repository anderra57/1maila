package enpresa;

public class Kurrikuluma {

	private String izena;
	private String NAN;
	private String helbidea;
	private String ePosta;
	private int adina;
	private String titulazioa;
	private int kalifikazioa;
	private LanTxostena lanenZerrenda;

	public Kurrikuluma(String pIzena, String pNAN, String pHelbidea,
			String pEPosta, int pAdina, String pTitulazioa, int pKalifikazioa) {
		this.izena = pIzena;
		this.NAN = pNAN;
		this.helbidea = pHelbidea;
		this.ePosta = pEPosta;
		this.adina = pAdina;
		this.titulazioa = pTitulazioa;
		this.kalifikazioa = pKalifikazioa;
		this.lanenZerrenda = new LanTxostena();
	}

	public boolean berdinakGara(Kurrikuluma pKur) {
		Boolean emaitza = false;
		if (this.NAN.equals(pKur.NAN)) {
			emaitza = true;
		}
		return emaitza;
	}

	public String getIzena(){
		return this.izena;
	}
	
	public int getKalifikazioa(){
		return this.kalifikazioa;
	}
	
	public boolean baldintzaBetetzenDu(String pTitu, int pEspe) {
		Boolean emaitza = false;
		if (this.lanenZerrenda.onargarria(pTitu,pEspe)){
			emaitza = true;
		}
		return emaitza;
	}
	
	public void gehituLana(Lana pLan){
		this.lanenZerrenda.gehituLana(pLan);
	}
	
	public void imprimatu() {
		System.out.println(this.getIzena()+"   "+this.getKalifikazioa());
	}
	
}
