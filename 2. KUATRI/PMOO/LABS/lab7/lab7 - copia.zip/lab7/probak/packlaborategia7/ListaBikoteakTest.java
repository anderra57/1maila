package packlaborategia7;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ListaBikoteakTest {
	ListaBikoteak l1 = ListaBikoteak.getListaBikoteak();
	Mutila mutila1,mutila2;
	Neska neska1,neska2,neska3;
	Bikotea b1,b2;

	@Before
	public void setUp() throws Exception {
		mutila1 = new Mutila("5642H","Adei","Arias",18);
		mutila2 = new Mutila("7532W","Ander","Prieto",18);
		neska1 = new Neska("7563L","Ane","Gomez",23);
		neska2 = new Neska("5311G","Maite","Larrimbe",18);
		neska3 = new Neska("6787K","Angela","Perez",23);
		b1 = new Bikotea(mutila1, neska1);
		b2 = new Bikotea(mutila2, neska2);
	}

	@After
	public void tearDown() throws Exception {
		l1 = null;
		b1 = null;
		b2 = null;
		mutila1 = null;
		mutila2 = null;
		neska1 = null;
		neska2 = null;
	}

	@Test
	public void testGetListaBikoteak() {
		assertNotNull(l1.getListaBikoteak());
	}

	@Test
	public void testGehituBikoteaModuOrdenatuan() {
		l1.getListaBikoteak().erreseteatu();
		l1.gehituBikoteaModuOrdenatuan(b1);
		
	}

	@Test
	public void testLortuHonenBikotea() {
		l1.gehituBikoteaModuOrdenatuan(b2);
		l1.gehituBikoteaModuOrdenatuan(b1);
		assertEquals(l1.getListaBikoteak().lortuHonenBikotea(neska3), null);
		assertEquals(l1.getListaBikoteak().lortuHonenBikotea(mutila2), neska2);
		assertEquals(l1.getListaBikoteak().lortuHonenBikotea(neska1), mutila1);
	}

	@Test
	public void testReajustatuBikoteak() {
		l1.getListaBikoteak().erreseteatu();
		l1.getListaBikoteak().gehituBikoteaModuOrdenatuan(b1);
		l1.getListaBikoteak().gehituBikoteaModuOrdenatuan(b2);
		
		l1.getListaBikoteak().reajustatuBikoteak();
	}

	@Test
	public void testErreseteatu() {
		l1.getListaBikoteak().erreseteatu();
	}

}
