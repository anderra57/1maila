package packteoria22;

import java.util.ArrayList;
import java.util.Iterator;

public class ListaKotxeak {
	private ArrayList<Kotxea> lista;
	
	public ListaKotxeak(){
		// Konturatu ez dugula ArrayLista parametro gisa jasotzen, berria sortzen dugu!!!!
		lista = new ArrayList<Kotxea>();
	}
	
	private Iterator<Kotxea> getIteradorea(){
		return this.lista.iterator();
	}
	
	private Kotxea bilatuKotxeaMatrikulaz(String pMatrikula){
		Kotxea k = null;
		Iterator<Kotxea> itr = this.getIteradorea();
		boolean aurkitua = false;
		while(itr.hasNext() && !aurkitua){
			Kotxea kotxe = itr.next();
			if (kotxe.matirulaHoriDut(pMatrikula)){
				aurkitua = true;
				k = kotxe;
			}
		}
		return k;
	}
	
	public boolean gehituKotxeBat(Kotxea pKotxea){
		return lista.add(pKotxea);
	}
	
	public int zenbatKmEginDitu(String pMatrikula){
		Kotxea kotxe = this.bilatuKotxeaMatrikulaz(pMatrikula);
		return kotxe.zenbatKmEginDitut();
	}
	
}
