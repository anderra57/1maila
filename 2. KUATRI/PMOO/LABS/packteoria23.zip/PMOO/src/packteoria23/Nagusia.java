package packteoria23;

public class Nagusia {
	
	public static void main(String[] args){
		ListaEskuderiak le = ListaEskuderiak.getListaEskuderiak();
		
		Eskuderia e1 = new Eskuderia("Ferrari");
		Eskuderia e2 = new Eskuderia("Mercedes");
		Eskuderia e3 = new Eskuderia("McLaren");
		
		le.gehituEskuderia(e1);
		le.gehituEskuderia(e2);
		le.gehituEskuderia(e3);
		
		Gidaria g1 = new Gidaria("Sebastian Vetel", "Alemana", true);
		e1.gehituGidaria(g1);
		Gidaria g2 = new Gidaria("Fernando Alonso", "Espainola", true);
		e3.gehituGidaria(g2);
		Gidaria g3 = new Gidaria("Lewis HAmilton", "Ingelesa", true);
		e2.gehituGidaria(g3);
		Gidaria g4 = new Gidaria("Kimi Raikkonen", "Finlandesa", true);
		e1.gehituGidaria(g4);
		Gidaria g5 = new Gidaria("Rubens Barrichello", "Brasildarra", false);
		e1.gehituGidaria(g5);
		Gidaria g6 = new Gidaria("Michael Schumacher", "Alemaniarra", false);
		e1.gehituGidaria(g6);
		Gidaria g7 = new Gidaria("Mika Hakkinen", "Finlandesa", false);
		e2.gehituGidaria(g7);
		
		le.lizentziaGabekoGidariakInprimatu();

	}

}
