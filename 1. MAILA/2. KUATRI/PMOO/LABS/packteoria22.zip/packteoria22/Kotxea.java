package packteoria22;

public class Kotxea {
	private String matrikula;
	private ListaBidaiak egindakoBidaiak;
	
	public Kotxea(String pMatrikula){
		this.matrikula = pMatrikula;
	}

	public String getMatrikula() {
		return matrikula;
	}

	public void setMatrikula(String matrikula) {
		this.matrikula = matrikula;
	}

	public ListaBidaiak getEgindakoBidaiak() {
		return egindakoBidaiak;
	}

	public void setEgindakoBidaiak(ListaBidaiak egindakoBidaiak) {
		this.egindakoBidaiak = egindakoBidaiak;
	}

	public boolean matirulaHoriDut(String pMatrikula){
		return this.matrikula.equals(pMatrikula);
	}
	
	public int zenbatKmEginDitut(){
		return egindakoBidaiak.bidaietanEgindakoKm();
	}
}
