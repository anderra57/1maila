package packproiektua;

public class Saloia extends Egoera{
	
	public Saloia(String pDeskribapena, ListaAkzioak pLista){
		super(pDeskribapena, pLista);
	}
	public void eszenatokiaInprimatu(){
		
	}
}
