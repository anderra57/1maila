package packteoria23;

import java.util.ArrayList;
import java.util.Iterator;

public class ListaGidariak {
	
	private ArrayList<Gidaria> zerrenda; 

	public ListaGidariak(){
		this.zerrenda = new ArrayList<Gidaria>();
	}
	
	public void gehituGidaria(Gidaria pGidaria) {
		this.zerrenda.add(pGidaria);
	}

	private Iterator<Gidaria> getIteradore(){
		return this.zerrenda.iterator();
	}
	
	public void lizentziaGabekoGidariakInprimatu() {
		Iterator<Gidaria> itr = this.getIteradore();
		while(itr.hasNext()){
			Gidaria gid = itr.next();
			if(!gid.lizentziaIndarrean()){
				gid.gidariaInprimatu();
			}
		}
		
	}

}
