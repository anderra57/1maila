package packteoria23;

import java.util.ArrayList;
import java.util.Iterator;

public class ListaEskuderiak {
	
	private static ListaEskuderiak nireEskuderiak = null;
	private ArrayList<Eskuderia> zerrenda;

	private ListaEskuderiak(){
		this.zerrenda = new ArrayList<Eskuderia>();
	}
	
	public static synchronized ListaEskuderiak getListaEskuderiak(){
		if (nireEskuderiak == null) {
			nireEskuderiak = new ListaEskuderiak();
		}
		return nireEskuderiak;
	}
	
	public void gehituEskuderia(Eskuderia pEskuderia){
		this.zerrenda.add(pEskuderia);
	}
	
	public void lizentziaGabekoGidariakInprimatu(){
		Iterator<Eskuderia> itr = this.getIteradore();
		while(itr.hasNext()){
			Eskuderia esk = itr.next();
			esk.lizentziaGabekoGidariakInprimatu();
		}
	}
	
	private Iterator<Eskuderia> getIteradore(){
		return this.zerrenda.iterator();
	}
	
}
