package packteoria23;

public class Eskuderia {
	private String izena;
	private ListaGidariak gidariZerrenda;
	
	public Eskuderia(String pIzena){
		this.izena = pIzena;
		this.gidariZerrenda = new ListaGidariak();
	}

	public void lizentziaGabekoGidariakInprimatu() {
		System.out.println(this.izena.toUpperCase());
		this.gidariZerrenda.lizentziaGabekoGidariakInprimatu();		
	}
	
	
	public void gehituGidaria(Gidaria pGidaria){
		this.gidariZerrenda.gehituGidaria(pGidaria);
	}
	
	

}
