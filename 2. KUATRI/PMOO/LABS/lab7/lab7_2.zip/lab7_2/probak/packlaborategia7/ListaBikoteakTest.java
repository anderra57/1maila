package packlaborategia7;

import junit.framework.TestCase;

public class ListaBikoteakTest extends TestCase {

	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testGetListaBikoteak() {
		fail("Not yet implemented");
	}

	public void testGehituBikoteaModuOrdenatuan() {
		fail("Not yet implemented");
	}

	public void testLortuHonenBikotea() {
		fail("Not yet implemented");
	}

	public void testReajustatuBikoteak() {
		fail("Not yet implemented");
	}

	public void testErreseteatu() {
		fail("Not yet implemented");
	}

}
